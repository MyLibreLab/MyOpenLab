/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author carmelo
 */
public class PinCapatibilityItem {

    public int pinCapatibility; // (INPUT/OUTPUT/ANALOG/PWM/SERVO, 0/1/2/3/4)
    public int pinResolution; // ???
    public int analog_pin=-1; // ???
}
